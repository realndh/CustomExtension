﻿TW.IDE.Dialogs.RenderChartDefinitionEditor = function () {

    this.title = "Render Definition";
    this.renderDialogHtml = function (widgetObj) {
      this.widgetObj = widgetObj;
      var html = '<div class="smartGrid-definition"><p>차트 디자인에 필요한 JSON 데이터를 넣어 주세요!</p><textarea id="smartGrid-textarea-definition" rows="10" cols="100" style="width:100%"></textarea></div>';
      return html;
    };

    this.afterRender = function (domElementId) {
        this.jqElementId = domElementId;
        this.jqElement = $('#' + domElementId);
        
//        var j = this.widgetObj.getProperty('renderString');
//        
//        if(j){
        	var jsonDefinitionAsString = this.widgetObj.getProperty('renderString');
        	this.jqElement.find("#smartGrid-textarea-definition").val(jsonDefinitionAsString);
        //}
        //widgetObj.setProperty('renderOptions', jsonDefinition);
    };

    // user is ready to leave the dialog ... validate and save properties in the appropriate property in the property bag
    this.updateProperties = function (widgetObj) {
        // Build the hidden "ColumnFormat" property from the information we have saved locally
        var r = true;
//        if(widgetObj.isPropertyBoundAsTarget('TableDefinition')) {
//          r = confirm("The TableDefinition property is already binded as target. If you populate it, the binding will not be taken into consideration anymore.");
//        }
//
//        if(r && widgetObj.getProperty('TableDefinition')) {
//            r = confirm("The TableDefinition property is already populated. Are you sure you want to update it?");
//        }

        if (r == true) {
          var thisItem = this;
          var definition = this.jqElement.find("#smartGrid-textarea-definition").val();
          
          if(definition.trim() != ''){
        	  var jsonDefinition =  eval("("+definition+")");
          }
          //console.log("defintion", definition);
          //var jsonDefinition = JSON.parse(definition);
          //var jsonDefinitionAsString = JSON.stringify(jsonDefinition);
          // set the property
          
          
          widgetObj.setProperty('renderString', definition);
          
          //widgetObj.setProperty('renderJSON', jsonDefinition);
          
        } else {
          this.jqElement.off();
          return false;
        }

        this.jqElement.off();
        return true;
    };
};
