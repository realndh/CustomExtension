/**
 * 20200128 hmpark 수정
 * library 선언부 주석 처리
 * metadata.xml 에 추가
 */
TW.Runtime.Widgets.customhighchart= function () {
	var valueElem;
	var thisWidget = this;
	this.renderHtml = function () {
		var Id = this.jqElementId;
		var containerId = "container" + Id;   
		var e = '<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/e3ps_common_chart.js"></script>' ;
			
		var t = 	'<div class="widget-content widget-customhighchart">'
			  +          '<div id="' + containerId + '" style="width:100%;height:100%;"></div>'
			  +'</div>';
		/*if(!jQuery().customhighchart){
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/highcharts.js"></script>');	
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/highcharts-more.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/modules/solid-gauge.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/modules/heatmap.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/ResizeSensor.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/js/modules/bullet.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/js/modules/drilldown.js"></script>');
			
		}*/
		return jQuery().customhighchart ? t : e + t ;
	};

	this.afterRender = function () {
		
		var Id = this.jqElementId;
		var containerId = "container" + Id;
		this.customhighchart = this.jqElement.customhighchart();
		
		//var renderJSON = this.getProperty("renderJSON");
		
		
		var renderString = this.getProperty("renderString");
		var renderJSON =  eval("("+renderString+")");
		var viewLegendSymbol = this.getProperty("viewLegendSymbol");
		var timezoneOffset = this.getProperty("timezoneOffset");
		var useUTCTime = this.getProperty("useUTCTime");
		var usePointClick = this.getProperty("usePointClick");
		var isDownloadMenu=this.getProperty("isDownloadMenu");
		
		//console.log("afterRender renderJSON ", renderJSON);
		
		this.jqElement.css("overflow", 'hidden');

		this.customhighchart.render(containerId, renderJSON, viewLegendSymbol,timezoneOffset, thisWidget, useUTCTime, usePointClick,isDownloadMenu);
		
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		//console.log("updatePropertyInfo === ", updatePropertyInfo);
		
		if (updatePropertyInfo.TargetProperty === 'renderJSON' || updatePropertyInfo.TargetProperty === 'renderString' || updatePropertyInfo.TargetProperty === 'timezoneOffset') {
			
			var Id = this.jqElementId;
			var containerId = "container" + Id;
			
			var chartJson = updatePropertyInfo.RawDataFromInvoke;
			
			//console.log("chartJson chartJson chartJson chartJson ", chartJson);
			
			var keys = Object.keys(chartJson);
			
			var renderString = this.getProperty("renderString");
			var timezoneOffset = this.getProperty("timezoneOffset");
			var renderJSON =  eval("("+renderString+")");
			var useUTCTime = this.getProperty("useUTCTime");
			
			if(renderJSON === undefined){
				renderJSON = chartJson;
			}else{
				for(var i = 0; i < keys.length; i++){
					var key = keys[i];
					renderJSON[key] = chartJson[key];
				}
			}
			//console.log("renderJSON renderJSON renderJSON renderJSON ", renderJSON);
			var viewLegendSymbol = this.getProperty("viewLegendSymbol");
			var usePointClick = this.getProperty("usePointClick");
			var isDownloadMenu=this.getProperty("isDownloadMenu");
			
			this.customhighchart.render(containerId, renderJSON, viewLegendSymbol, timezoneOffset, thisWidget, useUTCTime, usePointClick,isDownloadMenu);
			
		}else if (updatePropertyInfo.TargetProperty === 'updateSeries') {
			this.customhighchart.updateSeries(updatePropertyInfo.RawDataFromInvoke.array);
		}else if (updatePropertyInfo.TargetProperty === 'updateOptions') {
			this.customhighchart.updateOptions(updatePropertyInfo.RawDataFromInvoke);
		}else if (updatePropertyInfo.TargetProperty === 'point') {
			this.customhighchart.setPoint(updatePropertyInfo.SinglePropertyValue);
		}else if (updatePropertyInfo.TargetProperty === 'title') {
			this.customhighchart.setTitle(updatePropertyInfo.SinglePropertyValue);
		}else if (updatePropertyInfo.TargetProperty === 'addPoint') {
			var nshiftCount =  this.getProperty("shiftCount");
			this.customhighchart.addPoint(updatePropertyInfo.RawDataFromInvoke.array, nshiftCount);
		}else if (updatePropertyInfo.TargetProperty == 'addOptions') {
			this.customhighchart.addOptions(updatePropertyInfo.RawDataFromInvoke);
		}else if (updatePropertyInfo.TargetProperty === "renderData") {
			dataRows = updatePropertyInfo.ActualDataRows;
			this.customhighchart.renderDataInfo(dataRows);
		}else if(updatePropertyInfo.TargetProperty == 'updateMultiSeries') {
			this.customhighchart.updateMultiSeries(updatePropertyInfo.RawDataFromInvoke);
		//20201209 hmpark 추가 hoverPointIndex 추가
		}else if (updatePropertyInfo.TargetProperty === 'hoverPointIndex') {
			//var hoverPointIndexNumber =  this.getProperty("hoverPointIndex");
			this.customhighchart.hoverPointIndex(updatePropertyInfo.SinglePropertyValue);
		}
	};
	
	this.sendPlotLinesData = function (id, values) {
		thisWidget.setProperty("plotLineDatas", JSON.stringify(values));
		 if(id == 'plotLineA') {
			thisWidget.jqElement.triggerHandler('SendPlotLineADatas');
		}else if(id == 'plotLineB') {
			thisWidget.jqElement.triggerHandler('SendPlotLineBDatas');
		}
	};
	
	this.sendPointValue = function (pointValueX, pointValueY) {
		thisWidget.setProperty("clickedPointValueX", pointValueX)
		thisWidget.setProperty("clickedPointValueY", pointValueY);
	};
	
	this.body_append = function (script_src) {
		try{
			$("body").append(script_src);	
		}catch(err){
			
		}
	};
	
};