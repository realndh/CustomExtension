/**
 * 20200128 hmpark 수정
 * library 선언부 주석 처리
 * metadata.xml 에 추가
 */
TW.IDE.Widgets.customhighchart = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/CustomHighChart/ui/customhighchart/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'CustomHighChart',
			'description': '',
			'category': ['Common'],
			'isResizable': true,
            'supportsAutoResize': true,
            'customEditor': 'RenderChartDefinitionEditor',
            'customEditorMenuText': 'Render Definition',
			'properties': {
				'Highcharts Property': {
					'baseType': 'STRING',
					'defaultValue': 'Highcharts Property default value',
					'isBindingTarget': true
				},
				'renderJSON': {
					'baseType': 'JSON',
					'isBindingTarget': true,
				},
				'renderString': {
					'baseType': 'STRING',
					'isBindingTarget': true,
					'isBindingSource': true
				},
				'updateSeries': {
					'baseType': 'JSON',
					'isBindingTarget': true,
				},
				'updateOptions': {
					'baseType': 'JSON',
					'isBindingTarget': true,
				},
				'viewLegendSymbol': {
					'baseType': 'BOOLEAN',
					'isBindingTarget': true,
					'defaultValue': false,
				},
				'point': {
					'baseType': 'NUMBER',
					'isBindingTarget': true,
				},
				'title': {
					'baseType': 'STRING',
					'isBindingTarget': true,
				},
				'shiftCount': {
                    'description': 'Chart Shift Count',
                    'defaultValue': 3600,
                    'baseType': 'NUMBER',
                    'isVisible': true
                },
                'addPoint': {
					'baseType': 'JSON',
					'isBindingTarget': true,
				},
				'updateMultiSeries': {
					'baseType': 'JSON',
					'isBindingTarget': true
				},
				'timezoneOffset': {
					'baseType': 'NUMBER',
					'isBindingTarget': true
				},
                'isPlotLineDrag': {
                	'description': 'PlotLine Event',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
				'plotLineDatas': {
					'baseType': 'STRING',
					'isBindingSource': true,
				},
				'useUTCTime': {
					'baseType': 'BOOLEAN',
					'defaultValue': false
				},
				'usePointClick': {
					'description': 'use Point Click',
					'baseType': 'BOOLEAN',
					'defaultValue': false
				},
				'clickedPointValueX': {
					'isVisible': false,
					'baseType': 'STRING',
					'isBindingSource': true,
				},
				'clickedPointValueY': {
					'isVisible': false,
					'baseType': 'STRING',
					'isBindingSource': true,
				},
				'isDownloadMenu': {
					'baseType': 'BOOLEAN',
					'description': 'true : Download Menu visible',
					'defaultValue': true
				},
				//20201209 hmpark 추가 hoverPointIndex 추가
				'hoverPointIndex': {
					'baseType': 'NUMBER',
					'isBindingTarget': true,
				}
			}
		}
	};
	
	this.widgetEvents = function () {
        return {
        	'SendPlotLineADatas': { 'warnIfNotBound': true, 'description': 'SendPlotLineADatas'},
        	'SendPlotLineBDatas': { 'warnIfNotBound': true, 'description': 'SendPlotLineBDatas'},
        };
    };
    
	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':

			case 'renderString' :
				var Id = this.getProperty("Id");
				var containerId = "container" + Id;
				var renderString = this.getProperty("renderString");
				
				var renderJSON =  undefined;
				if(renderString.trim() != ''){
					renderJSON =  eval("("+renderString+")");
				}
				var viewLegendSymbol = this.getProperty("viewLegendSymbol");
				
				this.customhighchart.render(containerId, renderJSON, viewLegendSymbol);	
				break;
			case 'title' :
				this.customhighchart.setTitle(this.getProperty("title"));
				break;
			case 'timezoneOffset' :
				break;
			case 'Alignment':
				refreshHtml = true;
				break;
			case 'viewLegendSymbol' : 
				
				var viewLegendSymbol = this.getProperty("viewLegendSymbol");
				
				var Id = this.getProperty("Id");
				var containerId = "container" + Id;
				var renderString = this.getProperty("renderString");
				
				var renderJSON =  undefined;
				if(renderString.trim() != ''){
					renderJSON =  eval("("+renderString+")");
				}
				
				this.customhighchart.render(containerId, renderJSON, viewLegendSymbol);	
				
				break;
			case 'shiftCount' :
				break;
			case 'usePointClick' :
				this.updateVisibleProperties();
                TW.IDE.updateWidgetPropertiesWindow();
				break;
			default:
				break;
		}
		return refreshHtml;
	};

	this.renderHtml = function () {
		var Id = this.getProperty("Id");
		var containerId = "container" + Id;   
		var e = '<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/e3ps_common_chart.js"></script>' ;
			
		var t = 	'<div class="widget-content widget-customhighchart">'
			  +          '<div id="' + containerId + '" style="width:100%;height:100%;">'
			  
			  + '<table class="t1" height="100%" width="100%"><tr><td valign="middle" align="center"><span><img src="../Common/extensions/CustomHighChart/ui/customhighchart/logo.png"/><br> Custom HighChart</span></td></tr></table>'
				
			  + '</div>'
			  +'</div>';
		
		/*if(!jQuery().customhighchart){
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/highcharts.js"></script>');	
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/highcharts-more.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/modules/solid-gauge.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/modules/heatmap.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/ResizeSensor.js"></script>');
			this.body_append('<script type="text/javascript" src="../Common/extensions/CustomHighChart/ui/customhighchart/lib/js/modules/bullet.js"></script>');
		}*/
		return jQuery().customhighchart ? t : e + t ;
	};

	this.afterRender = function () {
		
		var Id = this.getProperty("Id");
		var containerId = "container" + Id;
		this.customhighchart = this.jqElement.customhighchart();
		
		//var renderJSON = this.getProperty("renderJSON");
				
		var renderString = this.getProperty("renderString");
		var renderJSON =  eval("("+renderString+")");
		var viewLegendSymbol = this.getProperty("viewLegendSymbol");
		
		console.log("renderJSON " , renderJSON);
		this.customhighchart.render(containerId, renderJSON, viewLegendSymbol);
	};
	
	this.updateVisibleProperties = function() {
        var props = this.allWidgetProperties()["properties"];

		if( this.getProperty('usePointClick') === true ) {
			props['clickedPointValueX']['isVisible'] = true;
			props['clickedPointValueY']['isVisible'] = true;
		} else {
			props['clickedPointValueX']['isVisible'] = false;
			props['clickedPointValueY']['isVisible'] = false;
		}
	};
	
	this.afterLoad = function () {
		this.updateVisibleProperties();
    };

	this.body_append = function (script_src) {
		try{
			//$("body").append(script_src);	
		}catch(err){
			
		}
	};
	
};