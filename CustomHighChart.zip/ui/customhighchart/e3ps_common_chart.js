(function($, window, document, undefined) {

	var pluginName = "customhighchart", dataKey = "plugin_" + pluginName;

	var Plugin = function(element, options) {

		this.element = element;
		this.init(options);

	};
	Plugin.prototype = {
		init : function(option) {
			$.extend(this.options, option);
		},
		render : function(containerId, dataSource, viewLegendSymbol, timezoneOffset, widget, useUTCTime, usePointClick, isDownloadMenu) {
			
			try{
				this.viewLegendSymbol = viewLegendSymbol;
				this.usePointClick = usePointClick;
				
				// console.log('render Call.......................', dataSource);

				var table = this.element.find('#' + containerId + ".t1");
				
				if (dataSource === undefined) {
					if (table) {
						table.show();
					}
					return;
				}

				if (table) {
					table.hide();
				}
				ResizeSensor.detach($('#' + containerId).parent('.widget-customhighchart'));
				//ResizeSensor.detach($('#' + containerId).parent('.widget-customhighchart'));

				this.chart = Highcharts.chart(containerId, dataSource, function(chart){
					if(isDownloadMenu){
						chart.update({	
							exporting: {
								menuItemDefinitions:{
									downloadXLS:{
										textKey: 'downloadXLS',
										onclick: function () {
											this.downloadXLS();
										},
										text: 'Download XLS'
									}
								},
								buttons: {
									contextButton: {
										symbol: 'url(../Common/extensions/CustomHighChart/ui/customhighchart/menuButton.png)',
										height: 24,
							            width: 24,
							            symbolSize: 24,
							            symbolX: 24,
							            symbolY: 24,
										menuItems: ['downloadPNG', 'downloadJPEG','downloadCSV','downloadXLS']
									}
								}
							}
						})
					}else{
						chart.update({	
							exporting: {
								enabled: false
							}
						})
					}
//					$(window).resize(function(){
//						try{
//							chart.redraw();
//		                	chart.reflow();
//						}catch(e){}
//	            	});
					
					if(usePointClick){
						chart.update({						
					    	plotOptions: {
								series: {
									cursor: 'pointer',
									point: {
										events: {
											click: function(clickEvent) {
												var pointValueX = this.x;
												var pointValueY = this.y;
												widget.sendPointValue(pointValueX, pointValueY);
											}
										}
									}
									
								}
							}
					    })
						
						try{
	                    	chart.redraw();
	                    	chart.reflow();
    					}catch(e){}
					}
					
	            	if(!viewLegendSymbol){
	            		var series = chart.series;
				        $(series).each(function (i, serie) {
				            if (serie.legendSymbol) {
				                serie.legendSymbol.hide();
				            }
				        });
	            	}
	            	var tabElement = null;
	            	
	            	if($('#' + containerId).parents(".hhitabs-actual-tab-contents").length > 0){
	            		
	            		var tabElement = $('#' + containerId).parents(".hhitabs-actual-tab-contents")[0];
	            		
	            		var isHide = false;
		            	if($(tabElement).css('display') == 'none'){
		            		$(tabElement).show();
		            		isHide = true;
		            	}
	            	}
	            	
	            	new ResizeSensor($('#' + containerId).parent('.widget-customhighchart'), function(){
    					
    					try{
	                    	chart.redraw();
	                    	chart.reflow();
    					}catch(e){}
                	});
	            	
	            	if(isHide){
	            		$(tabElement).hide();
	            	}
	            	
	            	setTimeout(function(){
	            		
	            		try{
	                    	chart.redraw();
	                    	chart.reflow();
    					}catch(e){}
	            		
	            	}, 1000);
				});

				if(!timezoneOffset){
					timezoneOffset = 0;
				}
				
				Highcharts.setOptions({
					global : {
						//default useUTC is true
						//useUTC : true,
						timezoneOffset: timezoneOffset
					},
					lang: {
						thousandsSep: ','
					},
					time: {
						useUTC: useUTCTime
					}
				});
				
				var isPlotLineDrag = false;
				
				if(widget != undefined) {
					isPlotLineDrag = widget.getProperty('isPlotLineDrag');
				}
				
				//console.log('isPlotLineDrag ======   '  + isPlotLineDrag);
				
				if(isPlotLineDrag) {
					
					var chart = this.chart;
					
					var plotLines = {
					  0: 'plotLineA',
					  1: 'plotLineB'
					};
			
					var line,
				    clickX,
				    clickY,
				    plotId;

					var start = function(e) {

					    for (var i = 0; i < chart.xAxis[0].plotLinesAndBands.length; i++) {
					    	var ll = chart.xAxis[0].plotLinesAndBands[i];
					    	if (e.target.id == ll.id) {
					    		line = chart.xAxis[0].plotLinesAndBands[i].svgElem;
					    		plotId = ll.id
					    	}
					    }
	
					    chart.update({
					    	chart: {
					    		zoomType: ''
					    	}
					    })
	
					    $(document).bind({
					    	'mousemove.line': step,
					    	'mouseup.line': stop
					    });
	
					    clickX = e.pageX - line.translateX;
					}

					var step = function(e) {
						line.translate(e.pageX - clickX)
					}

					var stop = function(e) {

						var values = new Object();
						var y = new Object();

						var xx = chart.hoverPoint.x;

						for (var i = 0; i < chart.series.length; i++) {
							var yy=0;
							var series = chart.series[i];
							for(var j=0; j<series.points.length; j++) {
						    	if(xx==series.points[j].x) {
						        	//console.log(series.name + " +++++++++++ ", series.points[j].y);
						    		yy = series.points[j].y;
						    		break;
						    	}
							}
							
							y[series.name] = yy;
							
						}
						
						values.x = xx;
						values.y = y;

						widget.sendPlotLinesData(plotId,values);
						
					    $(document).unbind('.line');
	
					    chart.update({
					    	chart: {
					    		zoomType: 'xy'
					    	}
					    })
					}
				  
					for (var i = 0; i < chart.xAxis[0].plotLinesAndBands.length; i++) {
						chart.xAxis[0].plotLinesAndBands[i].svgElem.attr({
					        id: plotLines[i],
						})
						.css({
							'cursor': 'pointer'
						})
						.translate(0, 0)
						.on('mousedown', start);
					}
				}
				
			}catch(e){
				console.log("error == ", e);
			}
		},
		updateOptions : function(updateOptionData){
			try{
				this.chart.update(updateOptionData);
				
				var yAxis = this.chart.yAxis[0];
				var xAxis = this.chart.xAxis[0];
				
				
				if(updateOptionData.yAxis){
					
					if(updateOptionData.yAxis.plotLines){
						var plotLines = updateOptionData.yAxis.plotLines;
						
						for(var i = 0; i < plotLines.length; i++){
							
							var plotLine = plotLines[i];
							
							plotLine.id = 'line' + i;
							
							yAxis.removePlotLine('line' + i);
			                yAxis.addPlotLine(plotLine);
						}
					}
					
				}else if(updateOptionData.xAxis){
					
					if(updateOptionData.xAxis.plotLines){
						var plotLines = updateOptionData.xAxis.plotLines;
						
						for(var i = 0; i < plotLines.length; i++){
							
							var plotLine = plotLines[i];
							
							plotLine.id = 'line' + i;
							
							xAxis.removePlotLine('line' + i);
							xAxis.addPlotLine(plotLine);
						}
					}
				}
				
				this.chart.redraw();
				this.chart.reflow();

			}catch(e){
				console.log("error == ", e);
			}
		},
		setTitle : function(title){
			this.chart.setTitle({text: title});
		},
		updateSeries : function(seriesData){
			try{
				
				if(this.chart.series != null && this.chart.series.length > 0){
					
					if(this.chart.series.length > seriesData.length){
						for(var i = this.chart.series.length; i >= seriesData.length - 1; i--){
							if(this.chart.series[i]){
								this.chart.series[i].remove();
							}
						}
					}
					
					for(var i = 0; i < seriesData.length; i++){
						
						if(this.chart.series[i]){
							this.chart.series[i].update(seriesData[i]);
						}else{
							this.chart.addSeries(seriesData[i]);
						}
					}
					
				}else if (seriesData.length > 0){
					for(var i = 0; i < seriesData.length; i++){
						
						this.chart.addSeries(seriesData[i]);
					}
				}
				
				//console.log("updateSeries Call complete");
				
				
				if(!this.viewLegendSymbol){
					var series = this.chart.series;
			        $(series).each(function (i, serie) {
			            if (serie.legendSymbol) {
			                serie.legendSymbol.hide();
			            }
			        });
            	}
				
				this.chart.redraw();
				this.chart.reflow();
				
			}catch(e){
				console.log("error == ", e);
			}
		},
		setPoint : function(point) {
			try {
				this.chart.series[0].points[0].update(parseInt(point));
			} catch (e) {
				
			}
		},
		setyAxisMax : function(max) {
			this.chart.yAxis[0].setExtremes(0, max);
		},
		addPoint : function(data, nshiftCount){
			
			if(data == null || data.length == 0){
				return;
			}
			
			//console.log('addPoint Start === ', data);
			
			try{
				
				var series = this.chart.series;
				
				for(var i = 0; i < series.length; i++){
					
					//console.log("series addPoint Call....");
					
					shift = series[i].data.length > nshiftCount;
					
					console.log(shift);
					
					var pointData = data[i];
					
					if(pointData){
						this.chart.series[i].addPoint(pointData, true, shift);
					}
					
					//console.log("series addPoint complete....");
				}
				
			}catch(e){
				console.log("error === ", e);
			}
		},
		addOptions : function(optionJson){
			
			try {
				var chart = this.chart;
			
				var length = Object.keys(optionJson).length;
				
				for(key in optionJson) {
					var options = optionJson[key];
					
					var optionName = options['options'];
					
					if(optionName == 'addAxis') {
						
						var count = options['series'];
						var axis = options['axis'];
						
						for(var j=0; j<count; j++) {
							
							if(axis[j] != null) {
								chart.addAxis(axis[j]);
							}
							
							chart.addSeries({
								data : []
							});
						}
					}
				}
			} catch(e) {
				console.log('addOptions error =====  ', e);
			}
		},
		updateMultiSeries : function(optionJson) {
			
			try {
				var chart = this.chart;
			
			
				for(key in optionJson) {
					var series = chart.series[key];
					var multiSeries = optionJson[key];
					
					for(var j=0; j<multiSeries.length; j++) {
						series.update(multiSeries[j]);
					}
				}
			} catch(e) {
				console.log('updateMultiSeries error =====   ', e);
			}
			
		},
		//20201209 hmpark 추가 hoverPointIndex 추가
		hoverPointIndex : function(data){
			
			//console.log("hoverPointIndex Started");
			if(data == null || data==undefined){
				return;
			}
			
			//console.log("hoverPointIndex ::: data = " + data);
			//console.log("hoverPointIndex ::: hoverPointIndexNumber = " + hoverPointIndexNumber);
			
			
			try{
				this.chart.series[0].data[data].setState('hover');
			}catch(e){
				console.log("error === ", e);
			}
			
		}
	};

	$.fn[pluginName] = function(options) {

		var plugin = this.data(dataKey);

		if (plugin instanceof Plugin) {
			if (typeof options !== 'undefined') {
				plugin.init(options);
			}
		} else {
			plugin = new Plugin(this, options);
			this.data(dataKey, plugin);
		}

		return plugin;
	};

}(jQuery, window, document));

function renderMarkers() {
	
	var chart = this,
    positions = this.legend.options.params,
    chart = this,
    xAxis = chart.xAxis[0],
    yAxis = chart.yAxis[0],
    renderer = chart.renderer,
    tempArray = [],
    singleMarkerPath;
	
	
	if(positions != undefined && positions != null){
	  positions.forEach(function(position, index) {
		singleMarkerPath = [
		  'M', yAxis.toPixels(position), xAxis.toPixels(-0.4 + index),
		  'L', yAxis.toPixels(position), xAxis.toPixels(0.4 + index)
		];

		if (!chart.additionalMarkers) {
		  tempArray.push(renderer.path(singleMarkerPath)
			.attr({
			  'stroke-width': 2,
			  stroke: '#ff5959',
			  zIndex: 10,
			  dashstyle: 'ShortDot',
			  zIndex:4
			})
			.add());
		} else {
		  chart.additionalMarkers[index].attr({
			d: singleMarkerPath
		  })
		}
	  });

	}
  if (!chart.additionalMarkers) {
    chart.additionalMarkers = tempArray;
  }
};



function drawCrossMarkers(){

	Highcharts.SVGRenderer.prototype.symbols.cross = function (x, y, w, h) {
		return ['M', x, y, 'L', x + w, y + h, 'M', x + w, y, 'L', x, y + h, 'z'];
	};
	if (Highcharts.VMLRenderer) {
		Highcharts.VMLRenderer.prototype.symbols.cross = Highcharts.SVGRenderer.prototype.symbols.cross;
	}

};